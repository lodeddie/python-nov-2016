from flask import Flask, render_template,flash, request, redirect
app = Flask(__name__)
app.secret_key = 'ThisIsSecret' # our index route will handle rendering our form
@app.route('/')
def index():
  return render_template("index.html")
# this route will handle our form submission
# notice how we defined which HTTP methods are allowed by this route
@app.route('/users',methods=['POST'])
def create_user():
   print "Got Post Info"
   # we'll talk about the following two lines after we learn a little more
   # about forms
   name = request.form['name']
   location = request.form['location']
   comments = request.form['comments']
   if len(name)<1 or len(comments)<1 or len(comments)>120:
   	flash('Invalid entry.')
   	return redirect('/')
   else:# redirects back to the '/' route
	return render_template('results.html',name=name,location=location,comments=comments)
app.run(debug=True) # run our server