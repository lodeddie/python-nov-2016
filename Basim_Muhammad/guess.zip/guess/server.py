import random
from flask import Flask,render_template,request,redirect,session  # Import Flask to allow us to create our app.
app = Flask(__name__)   
app.secret_key = 'ThisIsSecret' 

@app.route('/')
def hello_world():
	if 'number' in session:
		print session['number']
	else:
		session['number']=random.randrange(0, 101)
		print session['number']
	return render_template('index.html',)

@app.route('/answer',methods=['POST'])
def hello():
	guess=request.form['guess']
	if int(guess)>session['number']:
		session['response']='lower'
	elif int(guess)<session['number']:
		session['response']='higher'
	elif int(guess)==session['number']: 
		session['response']='Amazing!'
		del session['number']
	else:
		'Play the game correctly please'

	return redirect('/')

app.run(debug=True) 